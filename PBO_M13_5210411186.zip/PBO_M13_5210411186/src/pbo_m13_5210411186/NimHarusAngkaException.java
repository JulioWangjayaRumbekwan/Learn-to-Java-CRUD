package pbo_m13_5210411186;

public class NimHarusAngkaException extends Exception{

    @Override
    public String getMessage() {
        return "Nim yang diinputkan harus angka"; 
    }    
}